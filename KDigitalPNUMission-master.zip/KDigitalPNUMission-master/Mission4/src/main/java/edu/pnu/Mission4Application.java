package edu.pnu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mission4Application {

	public static void main(String[] args) {
		SpringApplication.run(Mission4Application.class, args);
	}

}
