1. Mission3에서 LogDAO를 추가한 버전

2. LogDaoH2Impl2.java : H2 데이터베이스 접근 객체

3. LogDaoFileImpl2.java : 파일 접근 객체
