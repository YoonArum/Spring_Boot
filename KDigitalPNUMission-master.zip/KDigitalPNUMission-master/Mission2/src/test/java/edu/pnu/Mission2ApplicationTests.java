package edu.pnu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mission2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
