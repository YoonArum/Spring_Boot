1. Mission1에서 JDBC를 이용해서 H2 Database를 사용하는 버전

2. Mission1과 비교해서 Dao 객체가 하나 더 추가된다.

3. 구성은 Controller - Service - Dao 로 업그레이드된다.