1. Mission5에서 JDBC Connection 방식을 JdbcTemplate으로 변경한 버전
