1. list 데이터를 생성해서 요청하는 정보를 제공하는 버전

2. 기본 구조는 Controller - Service만 있고 Service에서 데이터를 제공한다.